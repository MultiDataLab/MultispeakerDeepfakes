# Full MaSC dataset access

The full audio files are not included in this repository template.

Dataset access details will be added once public redistribution rights, hosting arrangements, and any applicable institutional requirements have been verified. Permission granted for use in a research project does not automatically imply permission to republish the audio.

Expected dataset composition: 1,084 authentic clips and 1,084 manipulated counterparts.
