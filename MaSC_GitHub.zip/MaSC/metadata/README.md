# Annotation metadata

The research corpus includes clip-level authenticity labels and start/end times for manipulated intervals. Metadata files are not included in this initial template.

A reproducible release should document:

- Unique clip and pair IDs (no identifying source details unless authorized)
- Authentic/manipulated label
- Manipulation start and end times (seconds; manipulated clips only)
- Parent-recording partition membership
- Audio duration and sample rate
- Any excluded or unavailable items

Any released metadata must be validated against the actual audio and must not expose source information beyond what publication permissions allow.
