# Audio samples

This folder is reserved for a small set of illustrative authentic and partially manipulated audio examples.

No audio is included in the initial repository template. Add samples only if redistribution of the source recordings and manipulated derivatives has been expressly authorized.

If samples become available, provide paired identifiers and refer to the metadata annotations instead of including personally identifying source information unnecessarily.
